import Link from "next/link";
import { ALL_TOPICS, getTopicUrl } from "@/lib/topics";
import { getArticleContent } from "@/content/registry";

// ═══════════════════════════════════════════════════════════════════════════
// components/homepage/PopularTopics.tsx
//
// Server Component. Cards are generated entirely from ALL_TOPICS (filtered
// to status === "published") — no hardcoded topic list. Reading time is
// read from content/registry.ts's getArticleContent() where available.
// Styling uses hp-* classes, not inline style props.
//
// Note on "difficulty": types/engineering/content.ts's ArticleMetadata has
// no difficulty field — only individual interview questions do. Rather
// than invent a fake difficulty rating, this card omits it.
// ═══════════════════════════════════════════════════════════════════════════

export default function PopularTopics() {
  const published = ALL_TOPICS.filter((t) => t.status === "published").sort(
    (a, b) => a.order - b.order
  );

  return (
    <section data-homepage-theme="light" aria-labelledby="popular-topics-heading" className="hp-section">
      <div className="hp-container">
        <div className="hp-section-header">
          <h2 id="popular-topics-heading" className="hp-h2">
            Popular topics
          </h2>
          <Link href="/learn" className="hp-link">
            View all →
          </Link>
        </div>

        {published.length === 0 ? (
          <p className="hp-text-muted">No published topics yet.</p>
        ) : (
          <ul className="hp-grid">
            {published.map((topic) => {
              const content = getArticleContent(topic.slug);
              const readingTime = content?.metadata.readingTimeMinutes;
              const category = topic.breadcrumb[topic.breadcrumb.length - 2] ?? topic.breadcrumb[0];

              return (
                <li key={topic.slug}>
                  <Link href={getTopicUrl(topic)} className="hp-card">
                    <span aria-hidden="true" className="hp-card-icon">
                      {topic.icon}
                    </span>
                    <span className="hp-eyebrow">{category}</span>
                    <h3 className="hp-h3">{topic.title}</h3>
                    <p className="hp-card-desc hp-clamp-2">{topic.description}</p>
                    <span className="hp-card-footer">
                      <span>{readingTime ? `${readingTime} min read` : ""}</span>
                      <span className="hp-link">Read article →</span>
                    </span>
                  </Link>
                </li>
              );
            })}
          </ul>
        )}
      </div>
    </section>
  );
}

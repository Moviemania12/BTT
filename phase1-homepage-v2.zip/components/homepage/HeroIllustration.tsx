// ═══════════════════════════════════════════════════════════════════════════
// components/homepage/HeroIllustration.tsx
//
// Reusable flat, blueprint-style isometric illustration for the homepage
// hero. Server Component — pure SVG markup, no interactivity, no client
// JS. Single accent color (currentColor via CSS var) + neutral outline
// strokes only, per the approved design system (no gradients, no
// photorealistic rendering, no neon).
//
// Exported as its own component (not inlined in HeroV2) so it can be
// reused anywhere else a hero-style illustration is needed later.
// ═══════════════════════════════════════════════════════════════════════════

export default function HeroIllustration() {
  return (
    <svg
      className="hp-illustration"
      viewBox="0 0 480 300"
      xmlns="http://www.w3.org/2000/svg"
      role="img"
      aria-labelledby="hero-illustration-title"
    >
      <title id="hero-illustration-title">
        Flat isometric illustration of a data center — power, cooling, and server systems
      </title>

      <g fill="none" stroke="var(--hp-border-hover)" strokeWidth="1.5">
        <rect x="60" y="70" width="360" height="180" rx="6" />
        <line x1="60" y1="110" x2="420" y2="110" />
      </g>

      <g fill="none" stroke="var(--hp-accent)" strokeWidth="2">
        <rect x="90" y="140" width="50" height="90" rx="3" />
        <rect x="150" y="140" width="50" height="90" rx="3" />
        <rect x="210" y="140" width="50" height="90" rx="3" />
        <line x1="90" y1="160" x2="140" y2="160" strokeWidth="1" opacity="0.5" />
        <line x1="90" y1="180" x2="140" y2="180" strokeWidth="1" opacity="0.5" />
        <line x1="90" y1="200" x2="140" y2="200" strokeWidth="1" opacity="0.5" />
      </g>

      <g fill="none" stroke="var(--hp-text-muted)" strokeWidth="1.5">
        <circle cx="330" cy="185" r="26" />
        <path d="M330 165 L330 175 M330 195 L330 205 M310 185 L320 185 M340 185 L350 185" />
      </g>

      <g fill="none" stroke="var(--hp-text-muted)" strokeWidth="1.5">
        <path d="M100 92 L100 82 L108 82 L108 92" />
        <path d="M120 92 L120 78 L128 78 L128 92" />
        <path d="M140 92 L140 85 L148 85 L148 92" />
      </g>

      <g fill="none" stroke="var(--hp-accent)" strokeWidth="1.5" opacity="0.6">
        <line x1="60" y1="250" x2="420" y2="250" strokeDasharray="4 3" />
      </g>
    </svg>
  );
}

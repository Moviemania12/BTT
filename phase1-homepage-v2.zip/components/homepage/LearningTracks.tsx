import Link from "next/link";
import { ALL_TOPICS } from "@/lib/topics";

// ═══════════════════════════════════════════════════════════════════════════
// components/homepage/LearningTracks.tsx
//
// Server Component. Topic counts are computed from ALL_TOPICS at request
// time. AI Infrastructure is included as a genuine "Coming Soon" card —
// confirmed from real data: all 24 topics with track "ai" currently have
// status "coming-soon" in topics.ts, so this label is factually accurate,
// not a placeholder guess.
// ═══════════════════════════════════════════════════════════════════════════

const TRACKS = [
  {
    track: "non-it" as const,
    title: "Non-IT Infrastructure",
    description: "Power, cooling, fire protection, and the physical systems that keep a data center running.",
    href: "/learn/non-it",
    comingSoon: false,
  },
  {
    track: "it" as const,
    title: "IT Infrastructure",
    description: "Servers, storage, networking, and the technology stack inside the data center.",
    href: "/learn/it",
    comingSoon: false,
  },
  {
    track: "ai" as const,
    title: "AI Infrastructure",
    description: "GPU clusters, ML platforms, and the infrastructure powering AI workloads.",
    href: "/learn/ai",
    comingSoon: true,
  },
];

export default function LearningTracks() {
  const counts = ALL_TOPICS.reduce<Record<string, number>>((acc, t) => {
    acc[t.track] = (acc[t.track] ?? 0) + 1;
    return acc;
  }, {});

  const publishedCounts = ALL_TOPICS.filter((t) => t.status === "published").reduce<Record<string, number>>(
    (acc, t) => {
      acc[t.track] = (acc[t.track] ?? 0) + 1;
      return acc;
    },
    {}
  );

  return (
    <section data-homepage-theme="light" aria-labelledby="tracks-heading" className="hp-section hp-section--subtle">
      <div className="hp-container hp-container--medium">
        <h2 id="tracks-heading" className="hp-h2 hp-h2--spaced">
          Learning tracks
        </h2>

        <div className="hp-grid hp-grid--wide">
          {TRACKS.map((t) =>
            t.comingSoon ? (
              <div key={t.track} className="hp-card hp-card--padded hp-card--disabled" aria-disabled="true">
                <div className="hp-card-header-row">
                  <h3 className="hp-h3">{t.title}</h3>
                  <span className="hp-badge hp-badge--coming-soon">Coming soon</span>
                </div>
                <p className="hp-card-desc">{t.description}</p>
                <span className="hp-text-sm hp-text-muted">
                  {counts[t.track] ?? 0} topics planned
                </span>
              </div>
            ) : (
              <Link key={t.track} href={t.href} className="hp-card hp-card--padded">
                <h3 className="hp-h3">{t.title}</h3>
                <p className="hp-card-desc">{t.description}</p>
                <span className="hp-link">
                  Explore track ({publishedCounts[t.track] ?? 0} topics) →
                </span>
              </Link>
            )
          )}
        </div>
      </div>
    </section>
  );
}

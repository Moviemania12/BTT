// ═══════════════════════════════════════════════════════════════════════════
// components/homepage/WhyBehindTheTech.tsx
//
// Server Component. Purely presentational — no data dependency. Styling
// uses hp-* classes, not inline style props.
// ═══════════════════════════════════════════════════════════════════════════

const REASONS = [
  {
    icon: "💬",
    title: "Simple language",
    description: "Complex infrastructure explained in plain Hinglish, without dumbing down the engineering.",
  },
  {
    icon: "🛠️",
    title: "Real engineering examples",
    description: "Worked calculations, real fault scenarios, and OEM-referenced practices — not generic theory.",
  },
  {
    icon: "🗺️",
    title: "Interactive learning",
    description: "Calculators, comparison tables, and diagrams built to be used, not just read.",
  },
  {
    icon: "📐",
    title: "Industry standards",
    description: "Every topic maps to the actual IEC, IEEE, NFPA, or IS standard that governs it.",
  },
];

export default function WhyBehindTheTech() {
  return (
    <section data-homepage-theme="light" aria-labelledby="why-heading" className="hp-section">
      <div className="hp-container">
        <h2 id="why-heading" className="hp-h2 hp-h2--spaced">
          Why Behind The Tech
        </h2>

        <ul className="hp-grid hp-grid--wide">
          {REASONS.map((r) => (
            <li key={r.title} className="hp-card">
              <span aria-hidden="true" className="hp-card-icon hp-card-icon--small">
                {r.icon}
              </span>
              <h3 className="hp-h3">{r.title}</h3>
              <p className="hp-card-desc">{r.description}</p>
            </li>
          ))}
        </ul>
      </div>
    </section>
  );
}

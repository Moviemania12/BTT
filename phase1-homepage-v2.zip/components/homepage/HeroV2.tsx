import Link from "next/link";
import { ALL_TOPICS } from "@/lib/topics";
import { getAllCalculators } from "@/lib/engineering/registry";
import HeroIllustration from "./HeroIllustration";

// ═══════════════════════════════════════════════════════════════════════════
// components/homepage/HeroV2.tsx
//
// Server Component. Uses the reusable HeroIllustration component instead
// of an inline generic graphic. Statistics are derived from real data
// (ALL_TOPICS, getAllCalculators) — never hardcoded. Styling uses the
// hp-* classes defined in globals.css, not inline style props.
// ═══════════════════════════════════════════════════════════════════════════

export default function HeroV2() {
  const publishedTopicCount = ALL_TOPICS.filter((t) => t.status === "published").length;
  const calculatorCount = getAllCalculators().length;

  return (
    <section data-homepage-theme="light" aria-labelledby="hero-heading" className="hp-section hp-section--hero">
      <div className="hp-container hp-container--narrow">
        <h1 id="hero-heading" className="hp-h1">
          Understand every system. Master every layer.
        </h1>

        <p className="hp-body">
          Practical, engineer-authored guides to data center infrastructure —
          from grid power to server rack, explained the way it actually works.
        </p>

        <HeroIllustration />

        <form role="search" aria-label="Search topics" className="hp-search-form">
          <span aria-hidden="true">🔍</span>
          <label htmlFor="hp-search" className="hp-sr-only">
            Search topics
          </label>
          <input
            id="hp-search"
            type="text"
            placeholder="Search UPS, Battery Bank, Earthing..."
            className="hp-search-input"
          />
        </form>

        <nav aria-label="Primary actions" className="hp-cta-row">
          <Link href="/learn" className="hp-btn hp-btn--primary">
            Start learning
          </Link>
          <Link href="/learn" className="hp-btn hp-btn--secondary">
            Explore topics
          </Link>
        </nav>

        <p className="hp-meta">
          {publishedTopicCount} published topics · {calculatorCount} engineering calculators
        </p>
      </div>
    </section>
  );
}

// ═══════════════════════════════════════════════════════════════════════════
// components/homepage/LearningRoadmapSimple.tsx
//
// Server Component. Static roadmap, ordered per the approved Product
// Design Document's canonical Data Center learning sequence:
//   Beginner → Electrical → Cooling → Fire → Monitoring → Security →
//   Networking → Servers → Cloud → AI Infrastructure
//
// This replaces the earlier generic "Choose/Learn/Practice/Master" version,
// which described a process, not an actual subject-matter progression.
// No progress data exists yet in Phase 1, so every step renders as
// "upcoming" — no fake completion state.
// ═══════════════════════════════════════════════════════════════════════════

const ROADMAP_STEPS = [
  "Beginner",
  "Electrical",
  "Cooling",
  "Fire",
  "Monitoring",
  "Security",
  "Networking",
  "Servers",
  "Cloud",
  "AI Infrastructure",
];

export default function LearningRoadmapSimple() {
  return (
    <section data-homepage-theme="light" aria-labelledby="roadmap-heading" className="hp-section hp-section--subtle">
      <div className="hp-container hp-container--medium">
        <h2 id="roadmap-heading" className="hp-h2 hp-h2--spaced hp-h2--center">
          Your learning roadmap
        </h2>

        <ol className="hp-roadmap-list" aria-label="Data center learning roadmap, in order">
          {ROADMAP_STEPS.map((step, i) => (
            <li key={step} className="hp-roadmap-step">
              <span className="hp-roadmap-dot hp-roadmap-dot--upcoming" aria-hidden="true">
                {i + 1}
              </span>
              <span className="hp-roadmap-label">{step}</span>
              {i < ROADMAP_STEPS.length - 1 && (
                <span className="hp-roadmap-arrow" aria-hidden="true">
                  →
                </span>
              )}
            </li>
          ))}
        </ol>
      </div>
    </section>
  );
}

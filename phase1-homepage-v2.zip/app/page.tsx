import Footer from "@/components/Footer";
import LoadingScreen from "@/components/LoadingScreen";
import HeroV2 from "@/components/homepage/HeroV2";
import LearningTracks from "@/components/homepage/LearningTracks";
import PopularTopics from "@/components/homepage/PopularTopics";
import ContinueLearning from "@/components/homepage/ContinueLearning";
import EngineeringTools from "@/components/homepage/EngineeringTools";
import WhyBehindTheTech from "@/components/homepage/WhyBehindTheTech";
import LearningRoadmapSimple from "@/components/homepage/LearningRoadmapSimple";

// ═══════════════════════════════════════════════════════════════════════════
// app/page.tsx — Phase 1 homepage redesign
//
// Previous sections (Hero, ArticlesSection, About, Categories, Videos,
// Stats, Newsletter, Contact) are no longer imported here but remain on
// disk unmodified, per the approved plan — nothing is deleted.
//
// Footer and LoadingScreen are reused as-is.
// ═══════════════════════════════════════════════════════════════════════════

export default function Home() {
  return (
    <>
      <LoadingScreen />
      <main>
        <HeroV2 />
        <LearningTracks />
        <PopularTopics />
        <ContinueLearning />
        <EngineeringTools />
        <WhyBehindTheTech />
        <LearningRoadmapSimple />
      </main>
      <Footer />
    </>
  );
}

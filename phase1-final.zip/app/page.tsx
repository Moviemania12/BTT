import Footer from "@/components/Footer";
import LoadingScreen from "@/components/LoadingScreen";
import HeroV2 from "@/components/homepage/HeroV2";
import LearningTracks from "@/components/homepage/LearningTracks";
import PopularTopics from "@/components/homepage/PopularTopics";
import ContinueLearning from "@/components/homepage/ContinueLearning";
import EngineeringTools from "@/components/homepage/EngineeringTools";
import WhyBehindTheTech from "@/components/homepage/WhyBehindTheTech";
import LearningRoadmapSimple from "@/components/homepage/LearningRoadmapSimple";

// ═══════════════════════════════════════════════════════════════════════════
// app/page.tsx — Phase 1 homepage
//
// PopularTopics.tsx now IS the category roadmap (evolved in place, not a
// separate component). Import name and homepage slot unchanged from the
// frozen baseline. All other sections and render order unchanged.
// ═══════════════════════════════════════════════════════════════════════════

export default function Home() {
  return (
    <>
      <LoadingScreen />
      <main>
        <HeroV2 />
        <LearningTracks />
        <PopularTopics />
        <ContinueLearning />
        <EngineeringTools />
        <WhyBehindTheTech />
        <LearningRoadmapSimple />
      </main>
      <Footer />
    </>
  );
}

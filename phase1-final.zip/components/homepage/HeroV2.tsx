import Link from "next/link";
import { ALL_TOPICS } from "@/lib/topics";
import { getAllCalculators } from "@/lib/engineering/registry";
import HeroIllustration from "./HeroIllustration";

// ═══════════════════════════════════════════════════════════════════════════
// components/homepage/HeroV2.tsx
//
// Visual-design revision: tighter vertical spacing (hp-section--hero-compact),
// two-column layout (headline/search/CTA on the left, illustration on the
// right) for better left/right visual balance and a more compact first
// screen. Data sources and component structure are unchanged. Zero inline
// style props — every visual adjustment is a new hp-* class modifier.
// ═══════════════════════════════════════════════════════════════════════════

export default function HeroV2() {
  const publishedTopicCount = ALL_TOPICS.filter((t) => t.status === "published").length;
  const calculatorCount = getAllCalculators().length;

  return (
    <section data-homepage-theme="light" aria-labelledby="hero-heading" className="hp-section hp-section--hero-compact">
      <div className="hp-container">
        <div className="hp-hero-grid">
          <div>
            <h1 id="hero-heading" className="hp-h1 hp-h1--left">
              Understand every system. Master every layer.
            </h1>

            <p className="hp-body hp-body--left">
              Practical, engineer-authored guides to data center infrastructure —
              from grid power to server rack, explained the way it actually works.
            </p>

            <form role="search" aria-label="Search topics" className="hp-search-form hp-search-form--tight">
              <span aria-hidden="true">🔍</span>
              <label htmlFor="hp-search" className="hp-sr-only">
                Search topics
              </label>
              <input
                id="hp-search"
                type="text"
                placeholder="Search UPS, Battery Bank, Earthing..."
                className="hp-search-input"
              />
            </form>

            <nav aria-label="Primary actions" className="hp-cta-row hp-cta-row--left">
              <Link href="/learn" className="hp-btn hp-btn--primary">
                Start learning
              </Link>
              <Link href="/learn" className="hp-btn hp-btn--secondary">
                Explore topics
              </Link>
            </nav>

            <p className="hp-meta hp-meta--left">
              {publishedTopicCount} published topics · {calculatorCount} engineering calculators
            </p>
          </div>

          <div className="hp-hero-illustration-col">
            <HeroIllustration />
          </div>
        </div>
      </div>
    </section>
  );
}
